<script lang="ts">
import { defineComponent } from "vue";

// VI LÖSER CUSTOM EVENTS I DENNA KOMPONENT!

export default defineComponent({
	name: "City",
});
</script>
<template></template>
<style scoped></style>
