export function formatRating(rating: number): string {
	return rating.toFixed(1);
}
