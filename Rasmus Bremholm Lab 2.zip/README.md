# Movie Time a Cinema Going App!

Project was built in VueJS - 3 (Options API) and uses The Movie Database to store data.

To run the app start by installing all neccecary dependancies using:
`npm install`
And then start the development server using:
`npm run dev`

Thanks to [Linda Jensen](https://github.com/lindajensen) for inspiration!
